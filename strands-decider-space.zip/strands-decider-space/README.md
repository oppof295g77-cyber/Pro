---
title: Strands Decider Playground
emoji: 🧭
colorFrom: blue
colorTo: indigo
sdk: gradio
sdk_version: 5.49.1
app_file: app.py
pinned: false
suggested_hardware: gpu
---

# Strands Decider Playground

A Gradio demo for [`StrandsAgents/strands-decider-E2B-gemma4-v1-2610`](https://huggingface.co/StrandsAgents/strands-decider-E2B-gemma4-v1-2610).

It supports the model's three typed decision primitives:
- **Yes/no** (`noul`)
- **Choose one** (`choice`)
- **Ordered score** (`score`)

The Space starts the upstream `strands-decider serve` HTTP service on an internal port and provides a small UI on port 7860. The first inference downloads the model and can take several minutes.

## Hardware

This checkpoint needs about 9 GB of GPU memory for bf16 weights according to its model card. CPU inference is possible but much slower and requires substantial RAM (about 19 GB for fp32 weights). Use a suitable GPU Space for a practical demo.

## Run locally

```bash
pip install -r requirements.txt
python app.py
```

## Notes

- Gemma 4 support currently requires installing the upstream GitHub `main` branch; the published PyPI package may not include it yet.
- The UI displays raw JSON returned by the model server.
- Confidence values are not guarantees. Evaluate on representative data before using decisions in production.
