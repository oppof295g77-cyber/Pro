import os
import subprocess
import time
import requests
import gradio as gr

MODEL_ID = "StrandsAgents/strands-decider-E2B-gemma4-v1-2610"
PORT = 8000
SERVER_URL = f"http://127.0.0.1:{PORT}"
_server = None

def start_model_server():
    global _server
    if _server is not None and _server.poll() is None:
        return
    cmd = ["strands-decider", "serve", MODEL_ID, "--device",
           "cuda" if os.environ.get("CUDA_VISIBLE_DEVICES", "") not in ("", "-1") else "cpu",
           "--port", str(PORT)]
    _server = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                               text=True, env=os.environ.copy())
    for _ in range(900):
        if _server.poll() is not None:
            raise RuntimeError("Model server exited during startup. Check Space logs and hardware settings.")
        try:
            r = requests.get(SERVER_URL + "/health", timeout=2)
            if r.ok:
                return
        except requests.RequestException:
            pass
        time.sleep(2)
    raise TimeoutError("Model server did not become ready in 30 minutes. The first model download can take time.")

def predict(state, question, kind, options):
    if not (state or "").strip():
        raise gr.Error("Enter some text to evaluate.")
    if not (question or "").strip():
        raise gr.Error("Enter a question.")
    try:
        start_model_server()
        if kind == "Yes / No":
            q = {"type": "noul", "instructions": question.strip()}
        elif kind == "Choose one":
            labels = [x.strip() for x in (options or "").split(",") if x.strip()]
            if len(labels) < 2:
                raise gr.Error("For Choose one, enter at least two comma-separated options.")
            q = {"type": "choice", "criteria": {label: label for label in labels}, "instructions": question.strip()}
        else:
            labels = [x.strip() for x in (options or "").split(",") if x.strip()]
            if len(labels) < 2:
                raise gr.Error("For Score, enter at least two ordered comma-separated labels (low to high).")
            q = {"type": "score", "criteria": labels, "instructions": question.strip()}
        payload = {"state": state.strip(), "questions": {"demo_question": q}}
        response = requests.post(SERVER_URL + "/v1/systemone", json=payload, timeout=600)
        response.raise_for_status()
        result = response.json()
        return "```json\n" + __import__("json").dumps(result, indent=2, ensure_ascii=False) + "\n```"
    except gr.Error:
        raise
    except Exception as exc:
        raise gr.Error(f"Inference failed: {exc}. Check the Space logs and hardware configuration.")

with gr.Blocks(theme=gr.themes.Soft(), title="Strands Decider Playground") as demo:
    gr.Markdown(
        "# 🧭 Strands Decider Playground\n"
        "Try a compact decision model for classification, routing, triage, and guardrail-style checks.\n\n"
        f"**Model:** [`{MODEL_ID}`](https://huggingface.co/{MODEL_ID})  ·  "
        "First run downloads model weights and may take several minutes."
    )
    with gr.Row():
        with gr.Column(scale=3):
            state = gr.Textbox(
                label="State / text to evaluate",
                value="Help! My payouts have been failing for 3 days!",
                lines=5,
                placeholder="Paste a ticket, message, snippet, or other context..."
            )
            question = gr.Textbox(
                label="Decision question",
                value="Which team should handle this?",
                lines=2
            )
            kind = gr.Radio(
                ["Yes / No", "Choose one", "Score"],
                value="Choose one",
                label="Question type"
            )
            options = gr.Textbox(
                label="Options / ordered score levels",
                value="billing, sales, retail",
                info="Comma-separated. For Score, list labels from lowest to highest."
            )
            run = gr.Button("Run decision", variant="primary")
        with gr.Column(scale=2):
            output = gr.Markdown(label="Model output")
            gr.Markdown(
                "### Example prompts\n"
                "- **Routing:** Which team should handle this? → `billing, sales, retail`\n"
                "- **Urgency:** Does this convey urgency? → Yes / No\n"
                "- **Sentiment:** How frustrated is the writer? → `calm, frustrated, angry`\n\n"
                "This is a decision model, not a text-generation chatbot. Treat confidence as a signal, "
                "not a guarantee; validate on your own data before production use."
            )
    run.click(predict, inputs=[state, question, kind, options], outputs=output)

if __name__ == "__main__":
    demo.queue(default_concurrency_limit=1).launch(server_name="0.0.0.0", server_port=7860)
